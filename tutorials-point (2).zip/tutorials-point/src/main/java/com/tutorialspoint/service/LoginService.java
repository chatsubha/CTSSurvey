package com.tutorialspoint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tutorialspoint.dao.RegistrationDao;
import com.tutorialspoint.domain.User;

@Service
public class LoginService {
	
	@Autowired
	RegistrationDao registrationDao;
	
	public User getUserDetails(String name) {
		return registrationDao.getUserDetails(name);
	}

}
