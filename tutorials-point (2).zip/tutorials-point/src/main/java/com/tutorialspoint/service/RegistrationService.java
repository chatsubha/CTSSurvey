package com.tutorialspoint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.tutorialspoint.dao.RegistrationDao;
import com.tutorialspoint.domain.User;

@Service
public class RegistrationService {
	
	@Autowired
	RegistrationDao registrationDao;
	@Autowired
	BCryptPasswordEncoder encoder;
	
	public String saveUserDetails(User user) {
		user.setPassword(encoder.encode(user.getPassword()));
		return registrationDao.doRegister(user);
	}

}
