package com.tutorialspoint.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tutorialspoint.service.RecaptchaService;

@RestController
public class LoginController {

	@Autowired
	RecaptchaService captchaService;
	//Spring Security see this :
		@RequestMapping(value = "/login", method = RequestMethod.GET)
		public ModelAndView login(
			@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout
			) {

			ModelAndView model = new ModelAndView();
			
			
			if (error != null) {
				model.addObject("error", "Invalid username and password!");
			}

			if (logout != null) {
				model.addObject("msg", "You've been logged out successfully.");
			}
			model.setViewName("login");

			return model;

		}
		
		@RequestMapping(value = "/login/loginHome", method = RequestMethod.POST)
		public ModelAndView loginHome(@RequestParam(name="g-recaptcha-response", required = false) String recaptchaResponse,
				  HttpServletRequest request ) {
			 
			
			ModelAndView model = new ModelAndView();
			model.setViewName("login");
			String error = null;
			 String ip = request.getRemoteAddr();
			 try {
			  String captchaVerifyMessage = 
			      captchaService.verifyRecaptcha(ip, recaptchaResponse);
			      if ( !StringUtils.isEmpty(captchaVerifyMessage)) {
				    error = captchaVerifyMessage;
				  }
				  if (error != null) {
					model.addObject("error", error);
					return model;
				}
			 } catch(Exception e) {
//				 model.addObject("error", "Could not verify the captcha");
//				 return model;
			 }
			 
			  
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			
			String role ="";
			for (GrantedAuthority authority :auth.getAuthorities()) {
				System.out.println("Inside home "+authority.getAuthority() +" principal "+auth.getPrincipal());
				role = authority.getAuthority();
			}
			
            if (role.equals("SUPER_USER")) {
            	model.setViewName("adminHomePage");
            	model.addObject("name",auth.getName());
            } else if(role.equals("GUEST_USER")) {
            	model.setViewName("userHomePage");
            	model.addObject("name",auth.getName());
            } else if(role.equals("LOGGED_IN_USER")) {
            	model.setViewName("userHomePage");
            	model.addObject("name",auth.getName());
            }
			return model;
			
		}
		
		@RequestMapping(value = "/registration", method = RequestMethod.GET)
		public ModelAndView registrationHome() {
			
			ModelAndView model = new ModelAndView();
			model.setViewName("Registration");
			return model;
		}
		
}
