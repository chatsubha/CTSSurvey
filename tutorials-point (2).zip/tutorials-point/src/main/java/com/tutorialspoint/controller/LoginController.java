package com.tutorialspoint.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tutorialspoint.domain.User;
import com.tutorialspoint.service.LoginService;
import com.tutorialspoint.service.RecaptchaService;
import com.tutorialspoint.util.CookieUtil;

@RestController
public class LoginController {

	@Autowired
	RecaptchaService captchaService;
	@Autowired
	LoginService loginService;
	
	//Spring Security see this :
		@RequestMapping(value = "/login", method = RequestMethod.GET)
		public ModelAndView login(
			@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout,
			HttpServletRequest request,HttpServletResponse response
			) {

			ModelAndView model = new ModelAndView();
			
			model.setViewName("login");
			if (error != null) {
				model.addObject("error", "Invalid username and password!");
				return model;
			}

			if (logout != null) {
				CookieUtil.clear(response, "JWT-TOKEN");
				model.addObject("msg", "You've been logged out successfully.");
				return model;
			}
			
			String name = CookieUtil.getValue(request, "JWT-TOKEN");
			System.out.println("Response from cooekie "+name);
			if(name!=null && !name.equals("")) {
				
				User user = loginService.getUserDetails(name);
				System.out.println("user" +user);
				if(user == null) {
					 return model;
				}
				String role = user.getRole();
				
				 if (role.equals("SUPER_USER")) {
		            	model.setViewName("adminHomePage");
		            	model.addObject("name",name);
		            } else if(role.equals("GUEST_USER")) {
		            	model.setViewName("userHomePage");
		            	model.addObject("name",name);
		            } else if(role.equals("LOGGED_IN_USER")) {
		            	model.setViewName("userHomePage");
		            	model.addObject("name",name);
		            } 
				 return model;
			}
			

			return model;

		}
		
		@RequestMapping(value = "/login/loginHome", method = {RequestMethod.POST,RequestMethod.GET})
		public ModelAndView loginHome(@RequestParam(name="g-recaptcha-response", required = false) String recaptchaResponse,
				  HttpServletRequest request,HttpServletResponse response ) {
			 
			
			ModelAndView model = new ModelAndView();
			
			String error = null;
			 String ip = request.getRemoteAddr();
			 try {
			  String captchaVerifyMessage = 
			      captchaService.verifyRecaptcha(ip, recaptchaResponse);
			      if ( !StringUtils.isEmpty(captchaVerifyMessage)) {
				    error = captchaVerifyMessage;
				  }
				  if (error != null) {
					model.setViewName("login");
					model.addObject("error", error);
					return model;
				}
			 } catch(Exception e) {
//				 model.addObject("error", "Could not verify the captcha");
//				 return model;
			 }
			 
			  
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			
			String role ="GUEST_USER";
			String name = "";
			if(auth!=null) {
				for (GrantedAuthority authority :auth.getAuthorities()) {
					System.out.println("Inside home "+authority.getAuthority() +" principal "+auth.getPrincipal());
					role = authority.getAuthority();
				}
				name = auth.getName();
				CookieUtil.create(response, "JWT-TOKEN", auth.getName(), false, 2147483647, "localhost");
			} else {
				name = CookieUtil.getValue(request, "JWT-TOKEN");
			}
			
			
			
            if (role.equals("SUPER_USER")) {
            	model.setViewName("adminHomePage");
            	model.addObject("name",name);
            } else if(role.equals("GUEST_USER")) {
            	model.setViewName("userHomePage");
            	model.addObject("name",name);
            } else if(role.equals("LOGGED_IN_USER")) {
            	model.setViewName("userHomePage");
            	model.addObject("name",name);
            } 
			return model;
			
		}
		
		@RequestMapping(value = "/registration", method = RequestMethod.GET)
		public ModelAndView registrationHome() {
			
			ModelAndView model = new ModelAndView();
			model.setViewName("Registration");
			return model;
		}
		
}
