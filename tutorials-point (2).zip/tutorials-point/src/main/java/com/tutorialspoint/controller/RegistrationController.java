package com.tutorialspoint.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tutorialspoint.domain.User;
import com.tutorialspoint.service.RecaptchaService;
import com.tutorialspoint.service.RegistrationService;

@RestController
public class RegistrationController {
	
	@Autowired
	RecaptchaService captchaService;
	@Autowired
	RegistrationService registrationService;
	
	@RequestMapping(value = "/registration/submit", method = RequestMethod.POST)
	public ModelAndView loginHome(User user,@RequestParam(name="g-recaptcha-response", required = false) String recaptchaResponse,
			  HttpServletRequest request ) {
		
		ModelAndView model = new ModelAndView();
		model.setViewName("login");
		String error = null;
		 String ip = request.getRemoteAddr();
		 try {
		  String captchaVerifyMessage = 
		      captchaService.verifyRecaptcha(ip, recaptchaResponse);
		      if ( !StringUtils.isEmpty(captchaVerifyMessage)) {
			    error = captchaVerifyMessage;
			  }
			  if (error != null) {
				model.addObject("error", error);
				return model;
			}
		 } catch(Exception e) {
//			 model.addObject("error", "Could not verify the captcha");
//			 return model;
		 }
		 
		String row =  registrationService.saveUserDetails(user);
		
		if(row.equals("0")) {
			model.addObject("error", "Registration failed");
			model.setViewName("Registration");
			return model;
		} else {
			
			model.setViewName("login");
			model.addObject("msg", "Registration has been successfully done .Please login here.");
			}
		 
		 
		 return model;
		
	}

}
