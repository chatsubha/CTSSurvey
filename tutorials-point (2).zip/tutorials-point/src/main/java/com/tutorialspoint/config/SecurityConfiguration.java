package com.tutorialspoint.config;



import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
	@Autowired
	DataSource datasource;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	@Value("${spring.queries.users-query}")
	private String usersQuery;
	@Value("${spring.queries.roles-query}")
	private String rolesQuery;
	
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
	    return bCryptPasswordEncoder;
	}
	
	@Override
	public void configure(WebSecurity web) throws Exception {
	    web.ignoring()
	            .antMatchers("/resources/**","/registration/**", "/static/**", "/css/**", "/js/**", "/images/**", "/console/**");
	}

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
    	
    	
        
        httpSecurity.authorizeRequests().antMatchers("/login").permitAll().antMatchers("/registration").permitAll().anyRequest().fullyAuthenticated()
                                                         .and()
                                                         .formLogin()
                                                         .loginPage("/login").permitAll()
                                                         .failureUrl("/login?error")
                                                         .passwordParameter("password")
                                                         .usernameParameter("username")
                                                         .successForwardUrl("/login/loginHome");
        httpSecurity.csrf().disable();
        httpSecurity.headers().frameOptions().disable();
        
        System.out.println(encoder.encode("123456"));
    }
    
    @Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//		auth.inMemoryAuthentication()
//                   .withUser("mkyong").password("{noop}123456").roles("USER");
    	auth.jdbcAuthentication().usersByUsernameQuery(usersQuery).authoritiesByUsernameQuery(rolesQuery)
    	.dataSource(datasource).passwordEncoder(new BCryptPasswordEncoder());
	}

}