package com.tutorialspoint.dao;

import org.springframework.stereotype.Repository;

import com.tutorialspoint.domain.User;

public interface RegistrationDao {
	
	public String doRegister(User user);

}
