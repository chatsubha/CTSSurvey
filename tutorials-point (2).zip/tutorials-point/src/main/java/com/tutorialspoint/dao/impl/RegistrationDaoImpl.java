package com.tutorialspoint.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.tutorialspoint.dao.RegistrationDao;
import com.tutorialspoint.domain.User;

@Repository
public class RegistrationDaoImpl implements RegistrationDao  {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Value("${spring.queries.registration.user}")
	private String usersQuery;
	@Value("${spring.queries.registration.user.role}")
	private String userRoleQuery;
	
	@Value("${spring.queries.login.roles-query}")
	private String rolesQuery;
	
	@Override
	public String doRegister(User user) {
		// TODO Auto-generated method stub
		
		try {

			int row = jdbcTemplate.update(usersQuery, new Object[] {user.getUsername(), user.getPassword(),user.getName(),user.getEmail()});
			int row1 = jdbcTemplate.update(userRoleQuery, new Object[] {user.getUsername(),2});
			return String.valueOf(row);
		} catch(Exception e) {
			e.printStackTrace();
			return "0";
		}
		
	}

	@Override
	public User getUserDetails(String name) {
		// TODO Auto-generated method stub
		
		List<User> userList = null;
		userList = jdbcTemplate.query(rolesQuery,new Object[] {name},new RowMapper<User>() {

				@Override
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					// TODO Auto-generated method stub
					User user = null;
					user = new User();
					user.setUsername(rs.getString(1));
					user.setEmail(rs.getString(2));
					user.setName(rs.getString(3));
					user.setRole(rs.getString(4));
						
					
					return user;
				}
			});
		
		
		if(userList!=null && userList.size()>0) {
			return userList.get(0);
		} else {
			return null;
		}
		
	}

}
