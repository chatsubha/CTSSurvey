package com.tutorialspoint.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.tutorialspoint.dao.RegistrationDao;
import com.tutorialspoint.domain.User;

@Repository
public class RegistrationDaoImpl implements RegistrationDao  {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Value("${spring.queries.registration.user}")
	private String usersQuery;
	@Value("${spring.queries.registration.user.role}")
	private String userRoleQuery;
	
	@Override
	public String doRegister(User user) {
		// TODO Auto-generated method stub
		
		try {

			int row = jdbcTemplate.update(usersQuery, new Object[] {user.getUsername(), user.getPassword(),user.getName(),user.getEmail()});
			int row1 = jdbcTemplate.update(userRoleQuery, new Object[] {user.getUsername(),2});
			return String.valueOf(row);
		} catch(Exception e) {
			e.printStackTrace();
			return "0";
		}
		
	}

}
