import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-player-component',
  templateUrl: './player-component.component.html',
  styleUrls: ['./player-component.component.css']
})
export class PlayerComponentComponent implements OnInit {

  constructor() { }

  @Input() sourceUrl:string;
  @ViewChild("mediavideo") _mediavideo:ElementRef;

  ngOnInit() {
    this._mediavideo.nativeElement.play();
    this.sourceUrl = "http://localhost:4200/assets/videos/mov_bbb.mp4";
  }
  get mediavideo(){

    return this._mediavideo;

  }

  

  

}
