import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VideoPalyerComponentComponent } from './video-palyer-component.component';

describe('VideoPalyerComponentComponent', () => {
  let component: VideoPalyerComponentComponent;
  let fixture: ComponentFixture<VideoPalyerComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VideoPalyerComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VideoPalyerComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
