import { Component, OnInit, ViewChild } from '@angular/core';
import { PlayerComponentComponent } from '../player-component/player-component.component';

@Component({
  selector: 'app-video-palyer-component',
  templateUrl: './video-palyer-component.component.html',
  styleUrls: ['./video-palyer-component.component.css']
})
export class VideoPalyerComponentComponent implements OnInit {

  constructor() { }

  url:string;
  @ViewChild(PlayerComponentComponent) player;

  ngOnInit() {
  }

  playVideo(event) {
    alert(event)
    this.url = event;
    let file = this.url.split('.');
		let ext = file[file.length - 1];
    if (this.player.mediavideo.nativeElement.canPlayType('video/' + ext)=='') {
      alert("This video cant play");
    } else {
      this.player.mediavideo.nativeElement.load();
      this.player.mediavideo.nativeElement.play();
    }
    
  }

}
