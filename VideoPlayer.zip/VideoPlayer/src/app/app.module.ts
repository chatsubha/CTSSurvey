import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayerComponentComponent } from './player-component/player-component.component';
import { PlayListComponentComponent } from './play-list-component/play-list-component.component';
import { PlayerControlComponentComponent } from './player-control-component/player-control-component.component';
import { VideoPalyerComponentComponent } from './video-palyer-component/video-palyer-component.component';

@NgModule({
  declarations: [
    AppComponent,
    PlayerComponentComponent,
    PlayListComponentComponent,
    PlayerControlComponentComponent,
    VideoPalyerComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
