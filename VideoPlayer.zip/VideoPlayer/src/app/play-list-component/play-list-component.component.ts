import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { YoutubeService } from '../youtube.service';

@Component({
  selector: 'app-play-list-component',
  templateUrl: './play-list-component.component.html',
  styleUrls: ['./play-list-component.component.css']
})
export class PlayListComponentComponent implements OnInit {

  constructor(public youtubeservice:YoutubeService) { }
  youtubeData:any;
  @Output() playEvent = new EventEmitter<string>();
  ngOnInit() {

   this.youtubeData = this.youtubeservice.callService();
  }

  playVideo(url) {
    this.playEvent.emit(url);
  }

}
