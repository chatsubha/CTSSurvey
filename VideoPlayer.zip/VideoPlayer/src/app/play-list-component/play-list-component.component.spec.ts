import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayListComponentComponent } from './play-list-component.component';

describe('PlayListComponentComponent', () => {
  let component: PlayListComponentComponent;
  let fixture: ComponentFixture<PlayListComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayListComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
