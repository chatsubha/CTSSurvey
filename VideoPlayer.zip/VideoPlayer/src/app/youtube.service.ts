import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class YoutubeService {

  constructor() { }

  json ={ "youtube":[ { "title":"Sadhguru and Physics", "url":"http://localhost:4200/assets/videos/mov_bbb.mp4", "status":"added", "approved":1, "likes":22, "unlike":4, "currentStatus":"playing", "exitplayprogress":30 }, 
  { "title":"Angular 6 Tutorial", "url":"http://localhost:4200/assets/videos/Joren_Falls_Izu_Japan.mp4", "status":"added", "approved":0, "likes":0, "unlike":0, "currentStatus":"paused", "exitplayprogress":0 }, 
  { "title":"Nikon P900 83X Zoom","url":"http://localhost:4200/assets/videos/big_buck_bunny.mp4", "status":"added", "approved":1, "likes":10, "unlike":1, "currentStatus":"paused", "exitplayprogress":80 }]}
  
  callService() {
    return this.json;
  }

}