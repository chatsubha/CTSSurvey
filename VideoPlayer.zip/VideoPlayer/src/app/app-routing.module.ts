import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlayerComponentComponent } from './player-component/player-component.component';
import { VideoPalyerComponentComponent } from './video-palyer-component/video-palyer-component.component';

const routes: Routes = [{path:"home",component:VideoPalyerComponentComponent},{path:"",component:VideoPalyerComponentComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
