import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayerControlComponentComponent } from './player-control-component.component';

describe('PlayerControlComponentComponent', () => {
  let component: PlayerControlComponentComponent;
  let fixture: ComponentFixture<PlayerControlComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayerControlComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayerControlComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
