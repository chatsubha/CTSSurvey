import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-player-control-component',
  templateUrl: './player-control-component.component.html',
  styleUrls: ['./player-control-component.component.css']
})
export class PlayerControlComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
