package com.tutorialspoint.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class LoginController {
	
	//Spring Security see this :
		@RequestMapping(value = "/login", method = RequestMethod.GET)
		public ModelAndView login(
			@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout) {

			ModelAndView model = new ModelAndView();
			if (error != null) {
				model.addObject("error", "Invalid username and password!");
			}

			if (logout != null) {
				model.addObject("msg", "You've been logged out successfully.");
			}
			model.setViewName("login");

			return model;

		}
		
		@RequestMapping(value = "/login/loginHome", method = RequestMethod.POST)
		public ModelAndView loginHome() {
			
			ModelAndView model = new ModelAndView();
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			model.setViewName("index");
			String role ="";
			for (GrantedAuthority authority :auth.getAuthorities()) {
				System.out.println("Inside home "+authority.getAuthority() +" principal "+auth.getPrincipal());
				role = authority.getAuthority();
			}
			
            if (role.equals("SUPER_USER")) {
            	model.setViewName("adminHomePage");
            	model.addObject("name",auth.getName());
            } else if(role.equals("GUEST_USER")) {
            	model.setViewName("userHomePage");
            	model.addObject("name",auth.getName());
            }
			return model;
			
		}
		
}
