DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS user_role;
DROP TABLE IF EXISTS role;

CREATE TABLE user (
  username VARCHAR(10) PRIMARY KEY,
  email VARCHAR(250) NOT NULL,
  password VARCHAR(250) NOT NULL,
  name VARCHAR(250) NOT NULL,
  ACTIVE BOOLEAN
);

CREATE TABLE user_role (
  username VARCHAR(15) PRIMARY KEY,
  role_id INT NOT NULL,
);

CREATE TABLE role (
  
  role_id int auto_increment PRIMARY KEY,
  role VARCHAR(15) NOT NULL
);



 
INSERT INTO role(role) values('GUEST_USER');
INSERT INTO role(role) values('LOGGED_IN_USER');
INSERT INTO role(role) values('SUPER_USER');

INSERT INTO user_role values('SA','2');
INSERT INTO user_role values('SB','3');


INSERT INTO user values('SA','SUBHASIS@GMAIL.COM','$2a$10$vMA263gLaKUzUjuTllhQGur5y/fEA8nk8yxkBkq4ZtgIwlwKMxNxu','SUBHASIS',1);
INSERT INTO user values('SB','SUBHASIS@GMAIL.COM','$2a$10$vMA263gLaKUzUjuTllhQGur5y/fEA8nk8yxkBkq4ZtgIwlwKMxNxu','SUBHASIS',1);