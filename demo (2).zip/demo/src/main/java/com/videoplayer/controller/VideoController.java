package com.videoplayer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class VideoController {
	
	@RequestMapping(value = "/")
	   public String index() {
	      return "videoPlayer";
	   }

}
