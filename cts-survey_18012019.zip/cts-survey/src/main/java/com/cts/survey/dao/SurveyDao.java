package com.cts.survey.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cts.survey.dto.Row;
import com.cts.survey.form.ContactForm;

@Repository
public interface SurveyDao {	
	
	public List<Row> getQuestion();
	public int insertData(ContactForm form,StringBuilder qstn,StringBuilder ans,String emails);
	public String getRole(String emailId);
	

}
