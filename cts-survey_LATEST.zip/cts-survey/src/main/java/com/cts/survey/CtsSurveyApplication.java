package com.cts.survey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
(scanBasePackages={"com.cts.survey"})
@EnableJpaAuditing
//@EnableWebSecurity
public class CtsSurveyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CtsSurveyApplication.class, args);
	}
}
