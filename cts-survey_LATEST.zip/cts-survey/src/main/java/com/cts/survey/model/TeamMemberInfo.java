package com.cts.survey.model;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "TMMEMBER_INFO")
//@NamedQuery(name = "TeamMemberInfo.fetchByPLEmail",query = "SELECT e.emailId FROM TeamMemberInfo e WHERE e.pLemailId =:emailId")
@NamedQuery(name = "TeamMemberInfo.fetchByPLEmail",query = "SELECT e.emailId FROM TeamMemberInfo e ")
@EntityListeners(AuditingEntityListener.class)
public class TeamMemberInfo implements Serializable{
	 
	  private static final long serialVersionUID = 1L;
	   
	    @Id
	    @Column(name ="TM_UNIQUE_ID")
	    @GeneratedValue(strategy=GenerationType.AUTO)
	    private int id;
	    
	   
	    @Column(name = "TM_EMAIL_ID")
	    @JsonProperty(value = "emailid")
	    private String emailId;
	    
	  
	    @Column(name = "PL_EMAIL_ID")
	    @JsonProperty(value = "pLEmailId")
	    private String pLemailId;

	    @Column(name = "ROLE")
	    private String role;
	    
	    @Column(name = "QUESTION_ID")
	    private String qstnId;
	    
	    @Column(name = "VALUE")
	    private String value;
	    
	    @Column(name = "PL_UNIQUE_ID")
	    private String plUniqueId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getpLemailId() {
		return pLemailId;
	}

	public void setpLemailId(String pLemailId) {
		this.pLemailId = pLemailId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getQstnId() {
		return qstnId;
	}

	public void setQstnId(String qstnId) {
		this.qstnId = qstnId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getPlUniqueId() {
		return plUniqueId;
	}

	public void setPlUniqueId(String plUniqueId) {
		this.plUniqueId = plUniqueId;
	}



}
