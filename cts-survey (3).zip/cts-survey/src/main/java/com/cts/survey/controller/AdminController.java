package com.cts.survey.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

//import com.cts.survey.model.ProjectLeadInfo;
//import com.cts.survey.model.TeamMemberInfo;
//import com.cts.survey.repository.MemberRepository;
import com.cts.survey.service.SurveyService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	SurveyService surveyService;
	
	
	
	//Save and Get Project Lead email IDS
	@PostMapping("/savePLEmailIds")
	public @ResponseBody String savePLMailIds(@RequestParam("emailid") String emailid) {
		System.out.println("emailids contoller" + emailid);
		surveyService.saveEmailIds("PL", emailid);
		return "saved data";
	}
		
		//Get Project Lead email ids
	@GetMapping("/getPLEmailIds")
	public @ResponseBody List<String> getPLEmailIds() {
		List<String> plEmailList = new ArrayList<String>();
		plEmailList = surveyService.getEmailInfo();
		System.out.println("plEmailList" + plEmailList);
		return plEmailList;
	}
	
	//Save and Get Team member email IDS
		@PostMapping("/saveTMEmailIds")
		public @ResponseBody String saveTMEmailIds(@RequestParam("emailid") String emailid,@RequestParam("plemailid") String plemailid) {
			System.out.println("emailids contoller" + emailid);
			surveyService.saveTMEmailIds("TM", emailid,plemailid);
			return "saved data";
		}
			//Get Team member email ids
		@GetMapping("/getTMEmailIds/{plemailid}")
		public @ResponseBody List<String> getTMEmailIds(@PathVariable(value = "plemailid") String plemailid) {
			List<String> memberList = new ArrayList<String>();
			//List<String> memberInfo = new ArrayList<String>();
			System.out.println("plemailid"+plemailid);
			memberList = surveyService.getTMEmailInfo(plemailid);
			System.out.println("memberInfo" + memberList);
			return memberList;
		}
		
		//Send mail to  Team member
				@PostMapping("/sendmailToMember")
				public @ResponseBody String sendMailToMembers(@RequestParam("emailid") String emailid) {
					System.out.println("emailids contoller" + emailid);
					surveyService.sendMailToMembers(emailid);
					return "Mail Sent";
				}
				
				
				
				@DeleteMapping("/delete")
				public @ResponseBody String deleteTables() {
					surveyService.deleteTables();
					return "Deleted all tables Data";
					
				}
		
		
	
	
	// GET team Lead email ids
	/*@GetMapping("/getTLEmailIds")
	public @ResponseBody List<String> getTLEmailIds(@RequestParam("plEmailId") String plEmailId) {
		System.out.println("plEmailId" + plEmailId);
		List<String> TLEmailList = surveyService.getTLEmails(plEmailId);
		System.out.println("TLEmailList" + TLEmailList);
		return TLEmailList;
	}*/
	
	/*@DeleteMapping("/delete")
	public void deleteAll(){
		System.out.println("===============Delete EmailIds===============");
		
		surveyService.deleteAll();
	}*/

}
