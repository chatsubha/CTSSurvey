package com.cts.survey.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.survey.form.EmailList;

@Repository
public interface SurveyDAO {
	
	public List<String> getEmailIds(String role,List<String> emailIds);
	public void saveEmailIds(String role,List<String> emailIds);
	public List<String> getTeamEmailIds(String role);

}
