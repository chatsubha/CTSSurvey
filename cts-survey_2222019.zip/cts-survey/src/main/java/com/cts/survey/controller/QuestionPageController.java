package com.cts.survey.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.survey.dto.Pages;
import com.cts.survey.form.ContactForm;
import com.cts.survey.service.QuestionPageService;

@RestController
public class QuestionPageController {
	
	@Autowired
	QuestionPageService questionPageService;
	
	@PostMapping("/getQuestion")
	public Pages processQuestions(HttpSession session) throws Exception {
		
		ContactForm form = (ContactForm)session.getAttribute("contactForm");
		Pages pages = questionPageService.getQuestions(form.getRole(),session);
		return pages;
		
	}

}
