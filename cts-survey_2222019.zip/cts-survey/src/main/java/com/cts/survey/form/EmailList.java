package com.cts.survey.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"id","emailId"})
public class EmailList {
	
	@JsonProperty
	private int id;
	@JsonProperty
	private String emailId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "EmailList[id="+id+"emailId="+emailId+"]";
	}
	

}
