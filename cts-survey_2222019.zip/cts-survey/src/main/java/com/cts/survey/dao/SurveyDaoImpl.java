package com.cts.survey.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.survey.dto.Row;
import com.cts.survey.form.ContactForm;

@Repository
@Transactional
public class SurveyDaoImpl implements SurveyDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	/*final String query = "select * from SURVEY_QUESTION";
	final String insertTeamLeadQuery = "update PROJECTLEAD_INFO set QUESTION_ID=?,VALUE=? where PL_EMAIL_ID=?";
	final String insertTMQuery = "update TMMEMBER_INFO set QUESTION_ID = ?,VALUE=? where TM_EMAIL_ID=?";
	final String insertPartInfo ="INSERT INTO PARTICIPANTS_INFO(ROLE,EMAIL_ID,PL_UNIQUE_ID,TM_UNIQUE_ID) VALUES (?,?,?,?)";
	final String selRoleFromPl= "SELECT A.ROLE FROM projectlead_info A WHERE A.PL_EMAIL_ID=?";
	final String selRoleFromTM= "SELECT A.ROLE FROM TMMEMBER_INFO A WHERE A.TM_EMAIL_ID=?";
	//final String insertTMInfo = "insert into TMMEMBER_INFO(TM_EMAIL_ID,PL_EMAIL_ID,ROLE,PL_UNIQUE_ID) values(?,?,?,?)";
	final String insertTMInfo = "INSERT INTO ctssurvey.TMMEMBER_INFO(TM_EMAIL_ID,ROLE,PL_UNIQUE_ID) VALUES (?,?,?)";*/
	
	
	final String query = "select * from survey_question where role=? AND status<>'D'";
	
	final String insertTeamLeadQuery = "update projectlead_info set question_id=?,value=? where pl_email_id=?";
	final String insertTMQuery = "update tmmember_info set QUESTION_ID = ?,VALUE=? where TM_EMAIL_ID=?";
	
	final String insertPartInfo ="INSERT INTO participants_info(ROLE,EMAIL_ID,PL_UNIQUE_ID,TM_UNIQUE_ID,status) VALUES (?,?,?,?,?)";
	
	final String selRoleFromPl= "SELECT A.role FROM projectlead_info A WHERE A.pl_email_id=?";
	
	final String selRoleFromTM= "SELECT A.ROLE FROM tmmember_info A WHERE A.TM_EMAIL_ID=?";
	
	//final String insertTMInfo = "INSERT INTO tmmember_info(TM_EMAIL_ID,ROLE,PL_UNIQUE_ID) VALUES (?,?,?)";
	final String checkStatus= "SELECT status FROM participants_info A WHERE EMAIL_ID=?";
	
	final String UpdateTMEmailsquery = "update tmmember_info SET email_sent_yn = ? WHERE TM_EMAIL_ID =?";
	final String UpdatePLEmailsquery = "update projectlead_info SET email_sent_yn = ? WHERE pl_email_id=?";
	
	@Override
	public List<Row> getQuestion(String role) {
		// TODO Auto-generated method stub
		
		List<Row> rows = jdbcTemplate.query(query,new Object[] {role}, new RowMapper() {

			@Override
			public Row mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				Row row = new Row();
				row.setQuestion(rs.getString("QUESTION"));
				row.setQuestion_id(rs.getString("QUESTION_ID"));
				return row;
			}
		});
		return rows;
	}

	@Override
	public int insertData(ContactForm form, StringBuilder qstn,StringBuilder ans,String emails) {
		// TODO Auto-generated method stub

		KeyHolder holder = new GeneratedKeyHolder();
		System.out.println("role==="+form.getRole());
		if(form.getRole().equals("L")) {
			jdbcTemplate.update(new PreparedStatementCreator() {           
	            @Override
	            public PreparedStatement createPreparedStatement(Connection connection)
	                    throws SQLException {
	                PreparedStatement ps = connection.prepareStatement(insertTeamLeadQuery,
	                    Statement.RETURN_GENERATED_KEYS); 
	                ps.setString(1, qstn.toString());
	                ps.setString(2, ans.toString());
	                ps.setString(3,form.getEmail());
	                
	                return ps;
	            }
	        }, holder);
			int id = jdbcTemplate.queryForObject("select pl_unique_id from projectlead_info where pl_email_id=?",new Object[]{form.getEmail()},Integer.class);
			jdbcTemplate.update(insertPartInfo,new Object[] {form.getRole(),form.getEmail(),id,"","C"});
			jdbcTemplate.update(UpdatePLEmailsquery,new Object[] {"C",form.getEmail()}); //update pl_lead_info table
			
//			String[] emailList;
//			if (emails.contains(";")) {
//				emailList = emails.split(";");
//			} else {
//				emailList = new String[] {emails};
//			}
//			
//			for (String email : emailList) {
//				//jdbcTemplate.update(insertTMInfo,new Object[]{email,form.getEmail(),"TM",id});
//				jdbcTemplate.update(insertTMInfo,new Object[]{email,"TM",id});
//			}
			
			
		} else {
			
			jdbcTemplate.update(new PreparedStatementCreator() {           

	            @Override
	            public PreparedStatement createPreparedStatement(Connection connection)
	                    throws SQLException {
	                PreparedStatement ps = connection.prepareStatement(insertTMQuery,
	                    Statement.RETURN_GENERATED_KEYS); 
	                ps.setString(1, qstn.toString());
	                ps.setString(2,ans.toString() );
	                ps.setString(3,form.getEmail());
	                
	                return ps;
	            }
	        }, holder);
			int id = jdbcTemplate.queryForObject("select TM_UNIQUE_ID from tmmember_info where TM_EMAIL_ID=?",new Object[]{form.getEmail()},Integer.class);
			jdbcTemplate.update(insertPartInfo,new Object[] {form.getRole(),form.getEmail(),null,id,"C"});
			jdbcTemplate.update(UpdateTMEmailsquery,new Object[] {"C",form.getEmail()}); //update tmmember table
		}
		return 0;
	}

	@Override
	public String getRole(String emailId) {
		// TODO Auto-generated method stub
		
		List<String> roleList = null;
		
		roleList = jdbcTemplate.queryForList(selRoleFromPl, new Object[] {emailId},String.class);
		
		if(roleList!=null && roleList.size()==0) {
			roleList = jdbcTemplate.queryForList(selRoleFromTM, new Object[] {emailId},String.class);
		}
		
		if (roleList ==null) {
			return  null;
		}
		if ( roleList.size()>0) {
			return roleList.get(0);
		} else {
			return null;
		}
		
	}
	
	@Override
	public String checkSurveyStatus(String emailId) {
		// TODO Auto-generated method stub
		
		List<String> statusList = null;
		
		statusList = jdbcTemplate.queryForList(checkStatus, new Object[] {emailId},String.class);
		
		
		if (statusList ==null) {
			return  null;
		}
		if ( statusList.size()>0) {
			return statusList.get(0);
		} else {
			return null;
		}
		
	}

}
