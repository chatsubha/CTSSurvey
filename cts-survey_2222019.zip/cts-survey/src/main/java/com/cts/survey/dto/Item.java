package com.cts.survey.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Item {
	
	  @JsonProperty("name")
	  private String name;
	  
	  @JsonProperty("title")
	  private String title;
	  
	  
	  
	  @JsonProperty("validators")
	  private List<Validator> validators;
	    

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}


	public List<Validator> getValidators() {
		return validators;
	}

	public void setValidators(List<Validator> validators) {
		this.validators = validators;
	}
	  
	  

}
