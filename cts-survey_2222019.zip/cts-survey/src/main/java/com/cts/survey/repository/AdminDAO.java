package com.cts.survey.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.survey.model.ProjectLeadInfo;
import com.cts.survey.model.TeamMemberInfo;

@Repository
public interface AdminDAO {
	
	public int insertProjectLeads(String pLEmailIds);
	public int insertTeamMembers(String TmemailIds,String pLEmailId);
	
	public List<ProjectLeadInfo> getProjectLeads();
	public List<TeamMemberInfo> getTeamMembers(String pLEmailId);
	
	public List<String> getProjectLeadEmailIds();
	
	public List<String> getEmailSentPLEmailIds();
	public List<String> getEmailSentTMEmailIds();
	
	//public int updateStatusPLEmailId(List<String> emailIds);
	//public int updateStatusTMEmailId(List<String> emailIds);
	
	public int updateStatusPLEmailId(String emailId);
     public int updateStatusTMEmailId(String emailId);
	public void deleteData();
	
		

}
