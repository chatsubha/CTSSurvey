package com.cts.survey.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.survey.model.TeamMemberInfo;

@Repository
public interface MemberRepository extends JpaRepository<TeamMemberInfo, UUID> {
	
	List<TeamMemberInfo> fetchByPLEmail();

}
