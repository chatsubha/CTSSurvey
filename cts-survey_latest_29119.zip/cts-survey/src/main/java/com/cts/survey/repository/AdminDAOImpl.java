package com.cts.survey.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.cts.survey.dto.Row;


@Repository
public class AdminDAOImpl implements AdminDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	final String query = "select * from ctssurvey.SURVEY_QUESTION";
	
	
	/*final String insertTeamLeadQuery = "INSERT INTO ctssurvey.PROJECTLEAD_INFO(PL_EMAIL_ID,ROLE) VALUES (?,?)";
	final String insertTMQuery = "INSERT INTO ctssurvey.TMMEMBER_INFO(TM_EMAIL_ID,PL_UNIQUE_ID) VALUES (?,?)";
	final String selectPLUniqueIdquery = "select PL_UNIQUE_ID from ctssurvey.PROJECTLEAD_INFO where PL_EMAIL_ID = ?";
	final String selectPLEmailsquery = "select PL_EMAIL_ID from ctssurvey.PROJECTLEAD_INFO";
	final String selectTMEmailsquery = "select TM_EMAIL_ID from ctssurvey.TMMEMBER_INFO WHERE PL_UNIQUE_ID = ?";
	final String deletePLInfoQuery = "Delete FROM ctssurvey.PROJECTLEAD_INFO";
	final String deleteTMInfoQuery = "Delete FROM ctssurvey.TMMEMBER_INFO";
	final String deletePartInfoQuery = "Delete FROM ctssurvey.PARTICIPANTS_INFO";*/
	
	final String insertTeamLeadQuery = "INSERT INTO PROJECTLEAD_INFO(PL_EMAIL_ID,ROLE) VALUES (?,?)";
	final String insertTMQuery = "INSERT INTO TMMEMBER_INFO(TM_EMAIL_ID,PL_UNIQUE_ID) VALUES (?,?)";
	final String selectPLUniqueIdquery = "select PL_UNIQUE_ID from PROJECTLEAD_INFO where PL_EMAIL_ID = ?";
	final String selectPLEmailsquery = "select PL_EMAIL_ID from PROJECTLEAD_INFO";
	final String selectTMEmailsquery = "select TM_EMAIL_ID from TMMEMBER_INFO WHERE PL_UNIQUE_ID = ?";
	final String deletePLInfoQuery = "Delete FROM PROJECTLEAD_INFO";
	final String deleteTMInfoQuery = "Delete FROM TMMEMBER_INFO";
	final String deletePartInfoQuery = "Delete FROM PARTICIPANTS_INFO";
	

	@Override
	public int insertProjectLeads(String pLEmailIds) {
		
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {           
            @Override
            public PreparedStatement createPreparedStatement(Connection connection)
                    throws SQLException {
                PreparedStatement ps = connection.prepareStatement(insertTeamLeadQuery,
                    Statement.RETURN_GENERATED_KEYS); 
                ps.setString(1, pLEmailIds);
                ps.setString(2, "PL");
                return ps;
            }
        }, holder);
		
		return 0;
	}

	@Override
	public int insertTeamMembers(String TmemailId, String pLEmailId) {
		String uniqueId = getPLUniqueID(pLEmailId);
		
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {           
            @Override
            public PreparedStatement createPreparedStatement(Connection connection)
                    throws SQLException {
                PreparedStatement ps = connection.prepareStatement(insertTMQuery,
                    Statement.RETURN_GENERATED_KEYS); 
                ps.setString(1, TmemailId);
                ps.setString(2, uniqueId);
                return ps;
            }
        }, holder);
		return 0;
	}

	@Override
	public List<String> getProjectLeads() {
		List<String> emailIds = new ArrayList<String>();
		  emailIds = this.jdbcTemplate.query(
				selectPLEmailsquery,
		        new RowMapper<String>() {
		            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		                return rs.getString("PL_EMAIL_ID");
		            }
		        });
		return emailIds;
	}

	@Override
	public List<String> getTeamMembers(String pLEmailId) {
		String uniqueId = getPLUniqueID(pLEmailId);
		//List<String> emailIds = new ArrayList<String>();
		 
		List<String> emailIds = jdbcTemplate.query(
				selectTMEmailsquery,
			    new Object[] {uniqueId},
			    new RowMapper<String>() {
			        public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			            return rs.getString(1);
			        }
			    });
		   
		return emailIds;
	}
	
	 
	public String getPLUniqueID(String pLEmailId) {
		// TODO Auto-generated method stub
		/*List<String> rows = jdbcTemplate.query(selectPLUniqueIdquery, new RowMapper() {
			@Override
			public String mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getString("PL_UNIQUE_ID");
				 
			}
		});*/
		 
		String uniqueId = (String)jdbcTemplate.queryForObject(
				selectPLUniqueIdquery, new Object[] { pLEmailId }, String.class);
		System.out.println("uniqueId"+uniqueId);
		return uniqueId;
		
	}
	
	@Override
	public void deleteData() {
		
		jdbcTemplate.execute(deletePLInfoQuery);
		jdbcTemplate.execute(deleteTMInfoQuery);
		jdbcTemplate.execute(deletePartInfoQuery);
		
	}

}
