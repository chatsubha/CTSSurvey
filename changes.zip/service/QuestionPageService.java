package com.cts.survey.service;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.survey.dao.SurveyDao;
import com.cts.survey.dto.Column;
import com.cts.survey.dto.Page;
import com.cts.survey.dto.Pages;
import com.cts.survey.dto.Question;
import com.cts.survey.dto.Row;
import com.cts.survey.form.ContactForm;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class QuestionPageService {
	
	@Autowired
	SurveyDao surveyDao;
	
	public Pages getQuestions() {
		
		List<Column> columnsList = new LinkedList<>();
		Column column = new Column();
		column.setText("Strongly Disagree");
		column.setValue(1);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Disagree");
		column.setValue(2);
		columnsList.add(column);
		
		column = new Column();
		column.setText("No option");
		column.setValue(3);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Agree");
		column.setValue(4);
		columnsList.add(column);
		
		column = new Column();
		column.setText("Strongly Agree");
		column.setValue(5);
		columnsList.add(column);
		
		List<Row> rows = surveyDao.getQuestion();
		
		Question question = new Question();
		question.setType("matrix");
		question.setName("Quality");
		question.setTitle("Please indicate if you agree or disagree with the following statements");
		question.setColumns(columnsList);
		question.setRows(rows);
		
		List<Question> questions = new LinkedList<>();
		questions.add(question);
		
		Page page = new Page();
		page.setQuestions(questions);
		List<Page> pageList = new LinkedList<>();
		pageList.add(page);
		
		Pages pages = new Pages();
		pages.setPages(pageList);
		pages.setTitle("Cognizant Survey Feedback question");
		pages.setShowProgressBar("top");
		
		return pages;
		
		
	}
	
	@Transactional
	public void insertDetails(String json,ContactForm form) throws JsonProcessingException, IOException {
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode node = mapper.readTree(json);
		Iterator<Entry<String,JsonNode>> it  =  node.fields();
		StringBuilder qstn = new  StringBuilder();
		StringBuilder ans = new  StringBuilder();
		
		while (it.hasNext()) {
			
			node = it.next().getValue();
			Iterator<Entry<String,JsonNode>> questionsIt  =  node.fields();
			while (questionsIt.hasNext()) {
				Map.Entry<String, JsonNode> qstnAnswerMap = questionsIt.next();
				
				qstn.append(qstnAnswerMap.getKey());
				if(questionsIt.hasNext()) {
					qstn.append(",");
				}
				
				ans.append(qstnAnswerMap.getValue());
				if(questionsIt.hasNext()) {
					ans.append(",");
				}
				
				
				System.out.println("Key"+qstnAnswerMap.getKey()+"VALUE " +qstnAnswerMap.getValue());
			}
		}
		
		surveyDao.insertData(form, qstn, ans);
	}

}
